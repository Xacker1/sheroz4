<?php
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
ob_start();
define('api_key','API_TOKEN');
$admin= "ADMIN_ID";
echo file_get_contents("https://api.telegram.org/bot" . api_key . "/setwebhook?url=" . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME']);

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".api_key."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------

function dirs($dir){

 if(is_dir($dir)){
}else{

  return mkdir($dir);

 }

}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
function stepbot($id,$value){
file_put_contents("baza/$id.step","$value");
}


#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
$update      = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
$cid  = $update->message->chat->id;
$fid  = $update->message->from->id;
$text  = $update->message->text;
$name = $update->message->first_name;
$user = $update->message->from->username;
$mid  = $update->message->message_id;
$name  = $update->message->from->first_name;
$message = $update->message;
######
$video = $message->video;
$file_id = $message->video->file_id;
}
$inline = $update->inline_query;
$inline_query = $update->inline_query->query;
if(isset($update->callback_query)){
  $cid = $update->callback_query->message->chat->id;
  $qid = $update->callback_query->id;
  $fid    = $update->callback_query->from->id;  
  $data      = $update->callback_query->data;  
  $mid2 = $update->callback_query->message->message_id;
  $mid = $update->callback_query->message->message_id;
}

#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
dirs("phone");
dirs("baza");

$step = file_get_contents("baza/$cid.step");
$num = file_get_contents("baza/all.num");

if(!$num){
file_put_contents("baza/all.num",0);
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
$azo=file_get_contents("azo.db");
if($message){
if(stripos($azo,"$cid")!==false){
}else{
file_put_contents("azo.db","$azo\n$cid");
}
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($text=="/start"){
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"✋ Assalomu alaykum, Botimizga xush kelibsiz.
🚀 Biz sizga bu botda pubg akkauntingizni sotishingiz mumkin yoki sotib olishingiz mumkin boʻladi!",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true, 
'keyboard'=>[
[['text'=>"📥 Sotib olish"],['text'=>"📤 Sotish"],],
[['text'=>"✍🏻 Qo’llav quvvatlash"]],
]]), 
]);
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($text=="🔙 Orqaga"){file_put_contents("baza/$cid.step","no");
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"🚀 Asosiy menyuga qaytingiz",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true, 
'keyboard'=>[
[['text'=>"📥 Sotib olish"],['text'=>"📤 Sotish"],],
[['text'=>"✍🏻 Qo’llav quvvatlash"]],
]]), 
]);
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($text=="✍🏻 Qo’llav quvvatlash"){
file_put_contents("baza/$cid.step","help");
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"📌 *Marhamat* endi fikr mulohaza uchun fikrlar yozing... ",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true, 
'keyboard'=>[
[['text'=>"🔙 Orqaga"]],
]]), 
]);
}
if($step=="help"){
file_put_contents("baza/$cid.step","helbp");
if($text=="🔙 Orqaga" or $text=="/start"){
file_put_contents("baza/$cid.step","no");
}else{
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"📬 Murojaat uchun raxmat",
"parse_mode"=>markdown,
'reply_markup'=>json_encode([
'resize_keyboard'=>true, 
'keyboard'=>[
[['text'=>"📥 Sotib olish"],['text'=>"📤 Sotish"],],
[['text'=>"✍🏻 Qo’llav quvvatlash"]],
]]), 
]);
}}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($text=="📥 Sotib olish"){
$array = rand(1,$num);
$bk=$array-1;
if(file_get_contents("phone/$array.caption")){
$caption = file_get_contents("phone/$array.caption");
$rasmid = file_get_contents("phone/$array.video");
$ega= file_get_contents("phone/$array.auth");
bot("sendvideo",[
"chat_id"=>$cid,
"video"=>$rasmid,
"caption"=>$caption,
'reply_markup'=>json_encode([
'resize_keyboard'=>true, 
'inline_keyboard'=>[
[['text'=>"$array/$num","callback_data"=>"=="]],
[['text'=>"⬅️","callback_data"=>"next=$bk"],['text'=>"➕ Sotib olish","url"=>"tg://user?id=$ega"],['text'=>"➡️","callback_data"=>"next=$array"]],
[['text'=>"🗑","callback_data"=>"del"]],
]]), 
]);
}else{
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"*😔 Afsuski hech narsa qo'shilmagan*",
"parse_mode"=>"markdown",
"reply_to_message_id"=>$mid,
]);
}
}

#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------


if(mb_stripos($data,"next=")!==false){
$next = explode("=",$data);
$ex = $next[1];
$nex = $ex+1;
$bk = $ex-1;
if(file_get_contents("phone/$nex.caption")){
$caption = file_get_contents("phone/$nex.caption");
$rasmid = file_get_contents("phone/$nex.video");
$ega= file_get_contents("phone/$nex.auth");
bot(deletemessage,[
"chat_id"=>$cid,
"message_id"=>$mid,
]);
bot("sendvideo",[
"chat_id"=>$cid,
"video"=>$rasmid,
"caption"=>$caption,
'reply_markup'=>json_encode([
'resize_keyboard'=>true, 
'inline_keyboard'=>[
[['text'=>"$nex/$num","callback_data"=>"=="]],
[['text'=>"⬅️","callback_data"=>"next=$bk"],['text'=>"➕ Sotib olish","url"=>"tg://user?id=$ega"],['text'=>"➡️","callback_data"=>"next=$nex"]],
[['text'=>"🗑","callback_data"=>"del"]],
]]), 
]);
}else{
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"😔 Afsuski hech narsa qo'shilmagan",
'show_alert'=>true,
]);
}
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($text == "📤 Sotish"){
file_put_contents("baza/$cid.step","video");
 bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"📂 *Yaxshi* endi akkauntdan 1-5 daqiqagacha video lavha yuboring! ",
"parse_mode"=>"markdown",
"reply_to_message_id"=>$mid,
'reply_markup'=>json_encode([
'resize_keyboard'=>true, 
'keyboard'=>[
[['text'=>"🔙 Orqaga"]],
]]), 
]);
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($step == "video"){
if($text=="🔙 Orqaga" or $text=="/start"){
file_put_contents("baza/$cid.step","no");
}else{
if($video){
$ok = $num+1;
file_put_contents("baza/$cid.num",$ok);
file_put_contents("phone/$ok.video",$file_id);
file_put_contents("baza/$cid.step","caption");
 bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"*😑 Akkaunt* haqida ma’lumot yozing

📙 *Akkauntning narxi* - 500 ming so’m
🚀 * Akkauntim ulangan* - googlega
🗣️ *Ichida pul bor* - 100 UC
🔥 * Qo'shimcha ma'lumotlar*...","parse_mode"=>"markdown",
"reply_to_message_id"=>$mid,
]);
}else{
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"📂 *Iltimos* endi akkauntdan 1-5 daqiqagacha video lavha yuboring!","parse_mode"=>"markdown",
"reply_to_message_id"=>$mid,
]);
}
}
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($step == "caption"){
if($text=="🔙 Orqaga" or $text=="/start"){
file_put_contents("baza/$cid.step","no");
}else{
if($text){
$inum = file_get_contents("baza/$cid.num");
file_put_contents("phone/$inum.caption",$text);
file_put_contents("phone/$inum.auth",$cid);
file_put_contents("baza/$cid.step","video");
 bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"🙃 *E’lon* Joylandi!",
"parse_mode"=>"markdown",
"reply_to_message_id"=>$mid,
]);
}else{
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"*👇 Akkaunt* haqida ma’lumot yozing

📙 *Akkauntning narxi* - 500 ming so’m
🚀 * Akkauntim ulangan* - googlega
🗣️ *Ichida pul bor* - 100 UC
🔥 * Qo'shimcha ma'lumotlar*...",
"parse_mode"=>"markdown",
"reply_to_message_id"=>$mid,
]);
}
}
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($data=='del'){
bot(deletemessage,[
"chat_id"=>$cid,
"message_id"=>$mid,
]);
}

if($text == "📊 Statistika"){
$u= explode("\n",$azo);
$count=count($u);
bot("SendMessage",[
"chat_id"=>$cid,
"text"=>"*🤩 Azolar*  $count",
"parse_mode"=>"markdown",
"reply_to_message_id"=>$mid,
]);
}

#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------

$panel = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"🗣 Userlarga xabar yuborish"],],
[["text"=>"📊 Statistika"],],
[["text"=>"🏠Bosh sahifaga qaytish"],],
]
]);

#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
$admin= "5103212057";
if($text=="/panel" and $cid==$admin){
bot('sendMessage',[
"chat_id"=>$cid,
"text"=>"Salom, Siz bot administratorisiz. Kerakli boʻlimni tanlang:",
"reply_markup"=>$panel,
]);
}
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
if($text=="🗣 Userlarga xabar yuborish" and $cid==$admin){
stepbot($cid,"send_post");
      bot("sendMessage",[
      "chat_id"=>$cid,
      "text"=>"📌 *Yuboriladigan* xabarni kiriting",
      "parse_mode"=>"markdown",
          "reply_markup"=>$panel,
          ]);
            }
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
     if($step=="send_post" and $cid==$admin){
        $file_id = $message->photo[0]->file_id;
        $caption = $message->caption;
                $ok = bot("sendPhoto",[
                  "chat_id"=>$cid,
                  "photo"=>$file_id,
                  "caption"=>$caption,
                  "parse_mode"=>"markdown",
                ]);
                if($ok->ok){
                  bot("sendPhoto",[
                    "chat_id"=>$cid,
                    "photo"=>$file_id,
                      "caption"=>"$caption\n\nYaxshi, rasmni qabul qildim!\nEndi tugmani na‘muna bo'yicha joylang.\n
[Dasturchi+https://t.me/uz_notoscam]\n[Yangiliklar+https://t.me/talabauz]",
"parse_mode"=>"html",
                      "disable_web_page_preview"=>true,
                    ]);
             file_put_contents("baza/$cid.text","$file_id{set}$caption");
             stepbot($cid,"xabar_tugma");
         }
     }
     #-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------
    if($step=="xabar_tugma" and $cid==$admin){
      $xabar = bot("sendMessage",[
        "chat_id"=>$cid,
        "text"=>"Connections...",
      ])->result->message_id;
      bot("deleteMessage",[
        "chat_id"=>$chat_id,
        "message_id"=>$xabar,
      ]);
   $usertext = file_get_contents("baza/$cid.text");
   $fileid = explode("{set}",$usertext);
   $file_id = $fileid[0];
   $caption = $fileid[1];
       preg_match_all("|\[(.*\]|U",$text,$ouvt);
$keyboard = [];
foreach($ouvt[1] as $ouut){
$ot = explode("+",$ouut);
array_push($keyboard,[["url"=>"$ot[1]", "text"=>"$ot[0]"],]);
}
$ok = bot("sendPhoto",[
"chat_id"=>$cid,
"photo"=>$file_id,
"caption"=>"Sizning rasmingiz ko‘rinishi:\n\n".$caption,
"parse_mode"=>"html",
"reply_markup"=>json_encode(
["inline_keyboard"=>
$keyboard
]),
]);
if($ok->ok){
$userlar = file_get_contents("azo.db");
$count = substr_count($userlar,"\n");
$count_member = count(file("azo.db"))-1;
  $ids = explode("\n",$userlar);
  foreach ($ids as $line => $id) {
    $clear = bot("sendPhoto",[
"chat_id"=>$id,
"photo"=>$file_id,
"caption"=>$caption,
"parse_mode"=>"html",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode(
["inline_keyboard"=>
$keyboard
]),
]);
unlink("baza/$cid.step");
}

if($clear){
$u= explode("\n",$azo);
$count=count($u);
  bot("sendMessage",[
    "chat_id"=>$cid,
    "text"=>"Xabar  userlarga yuborildi!",
    "parse_mode"=>"html",
  ]);
}
}else{
  bot("sendMessage",[
    "chat_id"=>$cid,
    "text"=>"Tugmani kiritishda xato bor. Iltimos, qaytadan yuboring:",
  ]);
unlink("baza/$cid.step");  
}
}
/*
#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------#-----Manbasiz olganingni ko'rsam sikaman

#------------#@galusuz####----------------@igalus----------------------#Sattorbek----------