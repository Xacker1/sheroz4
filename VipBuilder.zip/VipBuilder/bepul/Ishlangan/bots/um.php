<?php
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
ob_start();
define('API_KEY','API_TOKEN'); 
$admin = "ADMIN_ID"; // admin IDsi
$bot = "BOTNAME";
$kanalimiz = "@KingsOfPhp";
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$cid= $message->chat->id;
$text = $message->text;
$gid=$message->from->id;
$type = $message->chat->type;
$name = $message->from->first_name;
$mid = $message->message_id;
$uid = $update->callback_query->from->id;
$data = $update->callback_query->data;
$callmid = $update->callback_query->message->message_id;
$callcid = $update->callback_query->message->chat->id;
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/

/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
$panel = json_encode([
 'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"↗️ Xabar yuborish"]],
    [['text'=>"/stat"]],
    ]
    ]);
    
mkdir("calc");
$menu=json_encode([
'inline_keyboard'=>[
[['text'=>"ㅤ1ㅤ",'callback_data'=>"1"],['text'=>"ㅤ2ㅤ",'callback_data'=>"2"],['text'=>"ㅤ3ㅤ",'callback_data'=>"3"],['text'=>"ㅤ÷ㅤ",'callback_data'=>"÷"]],
[['text'=>"ㅤ4ㅤ",'callback_data'=>"4"],['text'=>"ㅤ5ㅤ",'callback_data'=>"5"],['text'=>"ㅤ6ㅤ",'callback_data'=>"6"],['text'=>"ㅤ×ㅤ",'callback_data'=>"×"]],
[['text'=>"ㅤ7ㅤ",'callback_data'=>"7"],['text'=>"ㅤ8ㅤ",'callback_data'=>"8"],['text'=>"ㅤ9ㅤ",'callback_data'=>"9"],['text'=>"ㅤ-ㅤ",'callback_data'=>"-"]],
[['text'=>"ㅤ.ㅤ",'callback_data'=>"."],['text'=>"ㅤ0ㅤ",'callback_data'=>"0"],['text'=>"ㅤCㅤ",'callback_data'=>"del1"],['text'=>"ㅤ+ㅤ",'callback_data'=>"+"]],
[['text'=>"ㅤ=ㅤ",'callback_data'=>"="]],
]
]);
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/


if($text=="/start"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Salom Kalkulator Botga Tashrif Buyurdingiz.

⬇️Marhamat Foydalanishni Boshlang!
",
'parse_mode'=>'html',
'reply_markup'=>$menu 
]);
}

/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="1"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$data",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/

if($data=="2"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="3"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="4"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="5"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="6"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="7"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="8"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="9"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="0"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="del"){
file_put_contents("calc/$uid.txt","  ");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
Marhamat Misol Kiriting!",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/


if($data=="del1"){
$calci=file_get_contents("calc/$uid.txt");
$get =  strlen($calci);
$get2= $get -1;
$resultt= substr($calci, 0, $get2);
file_put_contents("calc/$uid.txt","$resultt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>$resultt,'reply_markup'=>$menu]);} 
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="÷"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci/");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="+"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="-"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/calcii",'reply_markup'=>$menu]);}  

if($data=="×"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci*");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="."){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($data=="="){
$calci=file_get_contents("calc/$uid.txt");
$calcu = urlencode($calci);
$rs = file_get_contents('http://api.mathjs.org/v1/?expr='.$calcu);
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'parse_mode'=>'html','text'=>"
<i>$calci=</i>

<b>Javobi:</b> $rs ",'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"   C   ",'callback_data'=>"del"]],]]),]);}  

/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
$lichka=file_get_contents("azolar.txt");
if($type=="private"){
if(strpos($lichka,"$cid") !==false){
}else{
file_put_contents("azolar.txt","$lichka\n$cid");
}
}
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/
if($text=="/stat" and $cid==$admin){
$kanal=file_get_contents("kanal.txt");
$gruppa=file_get_contents("gruppa.txt");
$lichka=file_get_contents("azolar.txt");
$lich=substr_count($lichka,"\n");
$kn=substr_count($kanal,"\n");
$gr=substr_count($gruppa,"\n");
bot('sendMessage',[
'chat_id'=>$admin,
    'text'=> "<b>Bot statatistikasi:</b>    
├▶👤A'zolar: [ <b>$lich</b> ]
├
├▶📢Kanallar: <b>$kn</b>
├
└▶👥Guruxlar: <b>$gr</b>",
'parse_mode' => 'html',
]);
}
/*
@CalculatorUz_Bot kodi @DaMaS_BaSS Sirojiddin Tomonidan tuzildi 
va @KingsOfPhp  va @Infotuit va @UzXostRu Kanallari orqali TARQATILDI 
manbani o'zgartirmang*/

$xabar = file_get_contents("send.txt");
if($text == "↗️ Xabar yuborish"){
if($cid == $admin){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"*Userlarga yuboriladigan xabar matnini kiriting! Bekor qilish uchun /cancel ni bosing.*",
'parse_mode'=>"markdown",
'reply_markup'=>$back4_menu,
]); file_put_contents("send.txt","user");
}else{
bot("sendmessage",[
'chat_id'=>$cid,
'text'=> "*🤪😂 Bu funksiyani Faqat men $adminuser ishlata olaman.*",
'parse_mode'=>'Markdown',
]);
}
}
if($xabar=="user" and $cid==$admin){
if($text=="/cancel"){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Bekor qilindi!",
'parse_mode'=>"html",
]); unlink("send.txt");
}else{
$lich = file_get_contents("shekih.db");
$lichka = explode("\n",$lich);
foreach($lichka as $lichkalar){
$okuser=bot("sendmessage",[
'chat_id'=>$lichkalar,
'text'=>$text,
'parse_mode'=>'HTML'
]);
}
}
}
if($okuser){
bot("sendmessage",[
'chat_id'=>$admin,
'text'=>"<b>Hamma userlarga yuborildi</b>✅",
'parse_mode'=>'html',
'reply_markup'=>$panel,
]); unlink("send.txt");
}

//Xabar
if((mb_stripos($text, "/xabar")!==false) and $cid == $admin){
$id = explode(" ",$text);
$id1 = $id[1];
$id2 = $id[2];
$finish = bot('SendMessage', [
'chat_id'=>$id1,
'parse_mode'=>"markdown",
'text'=>"$id2

By: [@$bot]",
'disable_web_page_preview'=>true,
]);
}
if($finish){
bot('SendMessage', [
'chat_id'=>$admin,
'parse_mode'=>"markdown",
'text'=>"✔️ [$id1](tg://user?id=$id1) *Ga Xabar Yuborildi!✅*",
'parse_mode'=>'html',
'reply_markup'=>$panel
]);
}
?>