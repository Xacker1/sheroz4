<?php


$token = "API_TOKEN";
define('API_KEY', $token); 

$admin = "ADMIN_ID";

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$name = $message->from->first_name;
$fid = $message->from->id;
$botname = bot('getme',['bot'])->result->username;
$botid = bot('getme',['bot'])->result->id;
$mid = $message->message_id;
$new = $message->new_chat_member;
$newid = $new->id;
$cty = $message->chat->type;

if($newid !== NULL and $newid == $botid){
	 	bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"*Salom men guruhingizda kirdi chiqdilarni tozalayman, buning uchun menga admin berishingiz kerak!*",
        'parse_mode'=>"markdown"
        ]);
}


if ($tx == "/start" or $tx == "/start@$botname"){
    if($cty == "group" or $cty == "supergroup"){
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid
        ]);
        $st = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"*Bot lichkasiga yozing*",
        'parse_mode'=>"markdown"
        ]);
        sleep(1);
        $stt = $st->result->message_id;
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$stt
        ]);
    } else {
    bot('sendMessage',[
    'chat_id' => $cid,
    'text' => "Salom <b>$name</b> botimizga xush kelibsiz!\nBu bot guruhingizda kirdi chiqdini tozalaydi. Guruhga qo'shing:",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"➕ Guruhga qo'shish",'url'=>"https://t.me/$botname?startgroup=new"]],
    ]
        ])
    ]);
}
}

if(isset($update->message->new_chat_photo) or isset($update->message->new_chat_title) or isset($update->message->pinned_message) or isset($update->message->new_chat_member) or isset($update->message->left_chat_member)){
    bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid,
    ]);
}
