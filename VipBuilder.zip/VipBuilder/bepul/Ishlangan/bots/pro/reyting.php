<?php

$token = "API_TOKEN";
define('API_KEY',$token); 

$admin = "ADMIN_ID";

function  top($chatid){
$text = "👥 <b>TOP 20'ta eng ko'p reytingga ega a'zolar:</b>\n\n";
$files = glob("reyting/$chatid/*.txt");
foreach ($files as $user) {
$id = str_replace(["reyting/$chatid/", ".txt"], ["",""],$user);
$data[$id] = file_get_contents($user);
}
arsort($data);
$ar = array_reverse($data);
$i = 1;
foreach ($data as $id=>$pul) {
if ($i > 20)break;
$us = bot ('getChatMember', [
'chat_id'=> $chatid,
'user_id'=> $id,
]);
$res = $us->result->user->first_name;
$text .= "<b>$i)</b> <a href='tg://user?id=$id'>$res</a> <b>- [$pul]</b>\n";
$i++;
}
return $text;
}

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$cid = $message->chat->id;
$tx = $message->text;
$text = $message->text;
$name = $message->from->first_name;
$fid = $message->from->id;
$cty = $message->chat->type;
$reply = $message->reply_to_message;
$rfid = $reply->from->id;
$rfname = $reply->from->first_name;
$is_bot = $reply->from->is_bot;
$new = $message->new_chat_members;
$newid = $message->new_chat_member->id;
$botid = bot('getme',['bot'])->result->id;
$botname = bot('getme',['bot'])->result->username;
$adstep = file_get_contents("admin.step");


mkdir("reyting");
if($cty == "group" or $cty == "supergroup"){
  mkdir("reyting/$cid");
}

if($new !== NULL){
	if($newid == $botid){
		bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"*Salom men guruhingizdagi a'zolar reytingini hisoblashga ko'maklashaman.\nBuning uchun meni guruhingizga admin qiling!*",
        'parse_mode'=>"markdown"
		]);
	}
}

if($cty == "group" or $cty == "supergroup"){
  $get = file_get_contents("grid.txt");
    if(mb_stripos($get, $cid)==false){
        file_put_contents("grid.txt", "$get\n$cid");
    }
}else{
  $get = file_get_contents("usid.txt");
    if(mb_stripos($get, $fid)==false){
        file_put_contents("usid.txt", "$get\n$fid");
    }
}

if ($tx == "/start"){
    bot('sendMessage',[
    'chat_id' => $cid,
    'text' => "👋 Salom <b>$name</b>!\nBu bot sizga guruhingizdagi aʼzolarni reytingini koʻrsatishga xizmat qiladi!\n\n!my - sizning guruhdagi reytingingiz\n!msg - guruhga jami yozilgan xabarlar\n!top - eng ko'p reytingga ega 20 ta a'zolar reytinggi",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Guruhga qo'shish",'url'=>"https://t.me/$botname?startgroup=new"]]
    ]
    ])
    ]);
}

if($cty == "group" or $cty == "supergroup"){
if($rfid !== 777000 and $is_bot !== true){
if($tx == "+" or $tx == "✅" or mb_stripos($tx, "rahmat")!== false or mb_stripos($tx, "Rahmat")!== false or mb_stripos($tx, "raxmat")!== false or mb_stripos($tx, "Raxmat")!== false){
	if($fid !== $rfid and isset($reply)){
		if(file_exists("reyting/$cid/$rfid.txt")){
  $get = file_get_contents("reyting/$cid/$rfid.txt");
  $get++;
  file_put_contents("reyting/$cid/$rfid.txt",$get);
  bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=> "<a href='tg://user?id=$rfid'>$rfname</a> sizning reytingingiz <a href='tg://user?id=$fid'>$name</a> tomonidan oshirildi!\nSizning guruhdagi reytingingiz: <b>$get</b>",
    'parse_mode'=>"html"
    ]);
		} else {
			$get = 1;
			file_put_contents("reyting/$cid/$rfid.txt",$get);
		  bot('sendMessage',[
		    'chat_id'=>$cid,
		    'text'=> "<a href='tg://user?id=$rfid'>$rfname</a> sizning reytingingiz <a href='tg://user?id=$fid'>$name</a> tomonidan oshirildi!\nSizning guruhdagi reytingingiz: <b>$get</b>",
		    'parse_mode'=>"html"
		    ]);	
		}
	}
}

if($tx == "-" or $tx == "❎"){
	if($fid !== $rfid and isset($reply)){
		if(file_exists("reyting/$cid/$rfid.txt")){
  $get = file_get_contents("reyting/$cid/$rfid.txt");
  $get--;
  file_put_contents("reyting/$cid/$rfid.txt",$get);
  if($get < 0){
  	$get = 0;
  	file_put_contents("reyting/$cid/$rfid.txt",$get);
  }
  bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=> "<a href='tg://user?id=$rfid'>$rfname</a> sizning reytingingiz <a href='tg://user?id=$fid'>$name</a> tomonidan tushirildi!\nSizning guruhdagi reytingingiz: <b>$get</b>",
    'parse_mode'=>"html"
    ]);
		} else {
			$get = 0;
			file_put_contents("reyting/$cid/$rfid.txt",$get);
		bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=> "<a href='tg://user?id=$rfid'>$rfname</a> sizning reytingingiz <a href='tg://user?id=$fid'>$name</a> tomonidan tushirildi!\nSizning guruhdagi reytingingiz: <b>$get</b>",
    'parse_mode'=>"html"
    ]);
		}
	}
}
}

if($tx == "!my"){
 if(!file_exists("reyting/$cid/$fid.txt")){
 	$get = 0;
 	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=> "<a href='tg://user?id=$fid'>$name</a>\nSizning guruhdagi reytingingiz: <b>$get</b>",
    'parse_mode'=>"html",
    'reply_to_message_id'=>$mid
    ]);
 } else {
 	$get = file_get_contents("reyting/$cid/$fid.txt");
 	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=> "<a href='tg://user?id=$fid'>$name</a>\nSizning guruhdagi reytingingiz: <b>$get</b>",
    'parse_mode'=>"html",
    'reply_to_message_id'=>$mid
    ]);
 }
}

if($tx == "!top"){
$rey = top($cid);
bot ('sendMessage', [
'chat_id'=> $cid,
'parse_mode'=>"html",
'text'=> $rey,
'disable_web_page_preview'=>true
]);
}

if($tx == "!msg"){
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Guruhda ja'mi <b>$mid</b> ta xabar yozilgan.",
    'parse_mode'=>"html",
    'reply_to_message_id'=>$mid
	]);
}
}

if($text == "/panel" and $cid == $admin){
    bot('deleteMessage',[
    'chat_id' => $cid,
    'message_id' => $mid
    ]);
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Admin panel! Quyidagi menyudan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
    ]);
}

if($text == "📤 Userlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Userlarga yuboriladigan xabar matnini kiriting(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "us");
}

if($text == "📤 Guruhlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Guruhlarga yuboriladigan xabarni yuboring(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "gr");
}

if($text == "Bekor qilish"){
  unlink("admin.step");
  bot('sendmessage',[
    'chat_id'=>$admin,
    'text'=>"Bekor qilindi! Quyidagi menyudan foydalaning:",
    'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
]);
}

if($adstep == "us" and $text !== "Bekor qilish" and $cid == $admin){
     $userlar = file_get_contents("usid.txt");
     $idszs=explode("\n",$userlar);
     foreach($idszs as $idlat){
        $users = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($users){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha userlarga yuborildi."
        ]);
        }
     }


if($adstep == "gr" and $text !== "Bekor qilish" and $cid == $admin){
        $guruhlar = file_get_contents("grid.txt");
         $idszs=explode("\n",$guruhlar);
          foreach($idszs as $idlat){
          $guruhs = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($guruhs){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha guruhlarga yuborildi."
        ]);
        unlink("admin.step");
      } 
}

if($text == "📊 Statistika" and $cid == $admin){
    $us = file_get_contents("usid.txt");
    $gr = file_get_contents("grid.txt");

    $uscount = substr_count($us, "\n");
    $grcount = substr_count($gr, "\n");
    $count = $uscount + $grcount;

    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"📊 Statistika\n\nUserlar: *$uscount* ta\nGuruhlar: *$grcount* ta\nJami: *$count* ta",
    'parse_mode'=>"markdown"
    ]);
}